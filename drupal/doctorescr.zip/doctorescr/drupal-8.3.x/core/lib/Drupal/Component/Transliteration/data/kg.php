<?php

/**
 * @file
 * Kyrgyz transliteration data for the PhpTransliteration class.
 */

$overrides['kg'] = [
  0x41 => 'E',
  0x416 => 'C',
  0x419 => 'J',
  0x425 => 'X',
  0x426 => 'TS',
  0x429 => 'SCH',
  0x42E => 'JU',
  0x42F => 'JA',
  0x436 => 'c',
  0x439 => 'j',
  0x445 => 'x',
  0x446 => 'ts',
  0x449 => 'sch',
  0x44E => 'ju',
  0x44F => 'ja',
  0x451 => 'e',
  0x4A2 => 'H',
  0x4A3 => 'h',
  0x4AE => 'W',
  0x4AF => 'w',
  0x4E8 => 'Q',
  0x4E9 => 'q',
];
